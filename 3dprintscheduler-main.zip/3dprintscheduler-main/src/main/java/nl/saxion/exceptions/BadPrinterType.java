package nl.saxion.exceptions;

public class BadPrinterType extends RuntimeException {
    public BadPrinterType(String message) {
        super(message);
    }
}
