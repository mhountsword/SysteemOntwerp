package nl.saxion.exceptions;

public class PrintError extends Exception {
    public PrintError(String message) {
        super(message);
    }
}
