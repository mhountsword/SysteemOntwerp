package nl.saxion.models.strategy;

public enum Strategy {
    DEFAULT,
    EFFICIENT
}
