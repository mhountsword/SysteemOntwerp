package nl.saxion.models.observer;

public interface Updater {
        void update(int spoolchanges, int totalprints);
}
